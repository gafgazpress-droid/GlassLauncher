package com.example.glasslauncher

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.provider.Settings
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicText
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import androidx.palette.graphics.Palette
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

// Hava proqnozu üçün koordinatlar (Bakı). İstədiyiniz şəhərə görə dəyişin.
private const val LAT = 40.41
private const val LON = 49.87

private val Ink = Color(0xFF0D1030)

// Arxa fon rejimləri: 1 Şəffaf buz, 2 Bənövşəyi, 3 Buz + bənövşəyi qarışığı
data class BgTheme(val name: String, val base: Color, val glowA: Color, val glowB: Color)
val Themes = listOf(
    BgTheme("Şəffaf buz", Color(0xFF0A2233), Color(0xCC8FE3FF), Color(0x99CFF4FF)),
    BgTheme("Bənövşəyi", Color(0xFF14082E), Color(0xCC7B3FF2), Color(0x99B14CFF)),
    BgTheme("Buz + bənövşəyi", Color(0xFF0E1534), Color(0xCC8FE3FF), Color(0xAA8B4DFF))
)

data class AppItem(val label: String, val pkg: String, val icon: ImageBitmap, val accent: Color, val builtIn: Boolean)
data class InputItem(val label: String, val id: String)
data class Weather(val now: Int, val max: Int, val min: Int, val text: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val apps by produceState(emptyList<AppItem>()) {
                value = withContext(Dispatchers.Default) { loadApps() }
            }
            val prefs = remember { getPreferences(MODE_PRIVATE) }
            var themeIdx by remember { mutableIntStateOf(prefs.getInt("theme", 0).coerceIn(0, Themes.lastIndex)) }
            GlassLauncher(apps, themeIdx, onTheme = { themeIdx = it; prefs.edit().putInt("theme", it).apply() },
                onOpen = ::openApp, onSearch = ::openSearch,
                loadInputs = ::loadInputs, onInput = ::openInput,
                onWifi = { launch(Intent(Settings.ACTION_WIFI_SETTINGS)) },
                onSettings = { launch(Intent(Settings.ACTION_SETTINGS)) })
        }
    }

    // Tətbiqlərin orijinal ikonları və ikondan götürülmüş əsas rəng
    private fun loadApps(): List<AppItem> {
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER)
        return packageManager.queryIntentActivities(query, 0)
            .filter { it.activityInfo.packageName != packageName }
            .map {
                val bmp = it.loadIcon(packageManager).toBitmap(192, 192)
                val p = Palette.from(bmp).generate()
                val rgb = p.getVibrantColor(p.getDominantColor(0xFFFFFFFF.toInt()))
                AppItem(it.loadLabel(packageManager).toString(), it.activityInfo.packageName,
                    bmp.asImageBitmap(), Color(rgb),
                    (it.activityInfo.applicationInfo.flags and (ApplicationInfo.FLAG_SYSTEM or ApplicationInfo.FLAG_UPDATED_SYSTEM_APP)) != 0)
            }
            .sortedBy { it.label.lowercase() }
    }

    private fun openApp(app: AppItem) {
        packageManager.getLeanbackLaunchIntentForPackage(app.pkg)?.let { startActivity(it) }
    }

    private fun launch(vararg intents: Intent) {
        for (i in intents) { try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (e: Exception) {} }
    }

    // HDMI / AV və s. giriş mənbələrinin siyahısı
    private fun loadInputs(): List<InputItem> = try {
        val m = getSystemService(Context.TV_INPUT_SERVICE) as TvInputManager
        m.tvInputList.filter { it.isPassthroughInput }
            .map { InputItem((it.loadCustomLabel(this) ?: it.loadLabel(this)).toString(), it.id) }
    } catch (e: Exception) { emptyList() }

    private fun openInput(i: InputItem) =
        launch(Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(i.id)))

    // Google axtarışı / Assistant
    private fun openSearch() {
        val options = listOf(Intent(Intent.ACTION_ASSIST), Intent("android.search.action.GLOBAL_SEARCH"), Intent(Intent.ACTION_WEB_SEARCH))
        for (i in options) {
            try { startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return } catch (e: Exception) {}
        }
    }
}

suspend fun fetchWeather(): Weather? = withContext(Dispatchers.IO) {
    try {
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$LAT&longitude=$LON" +
            "&current=temperature_2m,weather_code&daily=temperature_2m_max,temperature_2m_min&timezone=auto&forecast_days=1")
        val c = url.openConnection() as HttpURLConnection
        c.connectTimeout = 8000; c.readTimeout = 8000
        val j = JSONObject(c.inputStream.bufferedReader().use { it.readText() })
        val cur = j.getJSONObject("current"); val d = j.getJSONObject("daily")
        Weather(
            cur.getDouble("temperature_2m").roundToInt(),
            d.getJSONArray("temperature_2m_max").getDouble(0).roundToInt(),
            d.getJSONArray("temperature_2m_min").getDouble(0).roundToInt(),
            weatherText(cur.getInt("weather_code"))
        )
    } catch (e: Exception) { null }
}

fun weatherText(code: Int) = when (code) {
    0 -> "Açıq"; 1, 2 -> "Az buludlu"; 3 -> "Buludlu"; 45, 48 -> "Dumanlı"
    in 51..57 -> "Çiskin"; in 61..67 -> "Yağışlı"; in 71..77 -> "Qarlı"
    in 80..82 -> "Leysan"; in 95..99 -> "Tufan"; else -> "—"
}

@Composable
fun GlassLauncher(apps: List<AppItem>, theme: Int, onTheme: (Int) -> Unit, onOpen: (AppItem) -> Unit, onSearch: () -> Unit,
                  loadInputs: () -> List<InputItem>, onInput: (InputItem) -> Unit, onWifi: () -> Unit, onSettings: () -> Unit) {
    val ctx = LocalContext.current
    var showSystem by remember { mutableStateOf(false) }
    var showInputs by remember { mutableStateOf(false) }
    var inputs by remember { mutableStateOf(emptyList<InputItem>()) }
    val firstInput = remember { FocusRequester() }
    LaunchedEffect(showInputs) { if (showInputs && inputs.isNotEmpty()) { delay(100); try { firstInput.requestFocus() } catch (e: Exception) {} } }
    val online by produceState(true) {
        while (true) {
            val cm = ctx.getSystemService(ConnectivityManager::class.java)
            value = cm?.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
            delay(5_000)
        }
    }
    val shown = remember(apps, showSystem) { if (showSystem) apps.filter { it.builtIn } else apps }
    val t = Themes[theme]
    val base by animateColorAsState(t.base, tween(700), label = "base")
    val glowA by animateColorAsState(t.glowA, tween(700), label = "glowA")
    val glowB by animateColorAsState(t.glowB, tween(700), label = "glowB")
    var focusedIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(showSystem) { focusedIndex = 0 }
    val time by produceState("") {
        while (true) { value = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()); delay(10_000) }
    }
    val weather by produceState<Weather?>(null) {
        while (true) { value = fetchWeather() ?: value; delay(30 * 60_000L) }
    }

    Box(
        Modifier.fillMaxSize().background(base).drawBehind {
            drawCircle(Brush.radialGradient(listOf(glowA, Color.Transparent), Offset(size.width * .1f, 0f), size.width * .5f),
                radius = size.width * .5f, center = Offset(size.width * .1f, 0f))
            drawCircle(Brush.radialGradient(listOf(glowB, Color.Transparent), Offset(size.width, size.height), size.width * .45f),
                radius = size.width * .45f, center = Offset(size.width, size.height))
            // yüngül "buzlu şüşə" parıltısı
            drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = .07f), Color.Transparent)))
        }
    ) {
        // Yuxarı sol: Google axtarış
        Row(Modifier.align(Alignment.TopStart).padding(40.dp), horizontalArrangement = Arrangement.spacedBy(12.dp), verticalAlignment = Alignment.CenterVertically) {
            SearchPill(onSearch)
            TvIconButton("Fon: ${t.name}", onClick = { onTheme((theme + 1) % Themes.size) }) { themeIcon(it) }
        }

        // Yuxarı sağ: giriş, Wi-Fi, tənzimləmə, daxili proqramlar + böyük saat və hava
        Row(Modifier.align(Alignment.TopEnd).padding(40.dp), horizontalArrangement = Arrangement.spacedBy(24.dp), verticalAlignment = Alignment.Top) {
            Row(Modifier.padding(top = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                TvIconButton("Giriş mənbəyi", active = showInputs, onClick = { inputs = loadInputs(); showInputs = !showInputs }) { inputIcon(it) }
                TvIconButton("Wi-Fi", dim = !online, onClick = onWifi) { wifiIcon(it) }
                TvIconButton("Tənzimləmələr", onClick = onSettings) { gearIcon(it) }
                TvIconButton("Televizorun daxili proqramları", active = showSystem, onClick = { showSystem = !showSystem }) { appsIcon(it) }
            }
            Column(horizontalAlignment = Alignment.End) {
                BasicText(time, style = TextStyle(Color.White, 56.sp, FontWeight.Light))
                weather?.let {
                    Spacer(Modifier.height(4.dp))
                    BasicText("${it.now}° · ${it.text}", style = TextStyle(Color.White, 22.sp, FontWeight.Medium))
                    BasicText("Maks ${it.max}°  Min ${it.min}°", style = TextStyle(Color(0xFFC9D0FF), 18.sp))
                }
            }
        }

        // Giriş mənbəyi paneli
        if (showInputs) {
            BackHandler { showInputs = false }
            Column(
                Modifier.align(Alignment.TopEnd).padding(top = 112.dp, end = 40.dp)
                    .clip(RoundedCornerShape(28.dp)).background(Color.White.copy(alpha = .14f))
                    .border(1.dp, Color.White.copy(alpha = .22f), RoundedCornerShape(28.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BasicText("Giriş mənbəyi", style = TextStyle(Color(0xFFC9D0FF), 18.sp))
                if (inputs.isEmpty()) BasicText("Giriş tapılmadı", style = TextStyle(Color.White, 20.sp))
                inputs.forEachIndexed { i, inp ->
                    Box(if (i == 0) Modifier.focusRequester(firstInput) else Modifier) {
                        ThemeChip(inp.label) { showInputs = false; onInput(inp) }
                    }
                }
            }
        }

        // Mərkəz: seçilmiş tətbiqin adı
        Column(Modifier.align(Alignment.Center).offset(y = (-40).dp), horizontalAlignment = Alignment.CenterHorizontally) {
            BasicText(shown.getOrNull(focusedIndex)?.label ?: "", style = TextStyle(Color.White, 72.sp, FontWeight.SemiBold, textAlign = TextAlign.Center))
        }

        // Aşağı: şüşə dok
        val first = remember { FocusRequester() }
        LaunchedEffect(shown) { if (shown.isNotEmpty()) { delay(150); try { first.requestFocus() } catch (e: Exception) {} } }
        val dock = RoundedCornerShape(44.dp)

        LazyRow(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 48.dp).widthIn(max = 1200.dp)
                .clip(dock).background(Color.White.copy(alpha = .12f)).border(1.dp, Color.White.copy(alpha = .22f), dock),
            contentPadding = PaddingValues(horizontal = 32.dp, vertical = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(24.dp),
            verticalAlignment = Alignment.Bottom
        ) {
            itemsIndexed(shown) { index, app ->
                var focused by remember { mutableStateOf(false) }
                val size by animateDpAsState(if (focused) 124.dp else 88.dp, label = "size")
                val shape = RoundedCornerShape(if (focused) 32.dp else 24.dp)
                Box(
                    Modifier.size(size)
                        .then(if (index == 0) Modifier.focusRequester(first) else Modifier)
                        .onFocusChanged { focused = it.isFocused; if (it.isFocused) focusedIndex = index }
                        .shadow(if (focused) 28.dp else 0.dp, shape, spotColor = app.accent, ambientColor = app.accent)
                        .clip(shape)
                        .border(if (focused) 4.dp else 0.dp, app.accent, shape)
                        .clickable { onOpen(app) }
                ) {
                    Image(app.icon, app.label, Modifier.fillMaxSize())
                }
            }
        }
    }
}

@Composable
fun SearchPill(onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(32.dp)
    Row(
        Modifier.height(64.dp)
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(Color.White.copy(alpha = if (focused) .96f else .14f))
            .border(1.dp, Color.White.copy(alpha = .25f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText("G", style = TextStyle(Color(0xFF4285F4), 30.sp, FontWeight.Bold))
        Spacer(Modifier.width(16.dp))
        BasicText("Google-da axtar", style = TextStyle(if (focused) Ink else Color.White, 22.sp))
    }
}

// Fonu dəyişən düymə: OK basdıqca 1 → 2 → 3 → 1 ...
@Composable
fun ThemeChip(text: String, onClick: () -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val shape = RoundedCornerShape(32.dp)
    Row(
        Modifier.height(64.dp)
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(Color.White.copy(alpha = if (focused) .96f else .14f))
            .border(1.dp, Color.White.copy(alpha = .25f), shape)
            .clickable(onClick = onClick)
            .padding(horizontal = 24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicText(text, style = TextStyle(if (focused) Ink else Color.White, 22.sp))
    }
}

// ---- Yuxarı sağ ikon düymələri ----
@Composable
fun TvIconButton(label: String, onClick: () -> Unit, active: Boolean = false, dim: Boolean = false, draw: DrawScope.(Color) -> Unit) {
    var focused by remember { mutableStateOf(false) }
    val fg = if (focused) Ink else Color.White
    Box(
        Modifier.size(52.dp)
            .onFocusChanged { focused = it.isFocused }
            .clip(CircleShape)
            .background(when { focused -> Color.White.copy(alpha = .96f); active -> Color.White.copy(alpha = .30f); else -> Color.White.copy(alpha = .12f) })
            .clickable(onClick = onClick)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.Center
    ) { Canvas(Modifier.size(26.dp).alpha(if (dim) .4f else 1f)) { draw(fg) } }
}

private fun DrawScope.stroke() = Stroke(size.width * .085f, cap = StrokeCap.Round)

fun DrawScope.inputIcon(c: Color) { // qutuya daxil olan ox
    val w = size.width
    val p = Path().apply {
        moveTo(.45f * w, .12f * w); lineTo(.88f * w, .12f * w); lineTo(.88f * w, .88f * w); lineTo(.45f * w, .88f * w)
        moveTo(.10f * w, .50f * w); lineTo(.66f * w, .50f * w)
        moveTo(.46f * w, .30f * w); lineTo(.66f * w, .50f * w); lineTo(.46f * w, .70f * w)
    }
    drawPath(p, c, style = stroke())
}

fun DrawScope.wifiIcon(c: Color) {
    val w = size.width; val cx = w / 2; val cy = w * .86f
    for (r in listOf(.80f, .55f, .30f)) {
        drawArc(c, 225f, 90f, false, Offset(cx - r * w, cy - r * w), Size(2 * r * w, 2 * r * w), style = stroke())
    }
    drawCircle(c, w * .07f, Offset(cx, cy))
}

fun DrawScope.gearIcon(c: Color) {
    val w = size.width; val ctr = Offset(w / 2, w / 2)
    drawCircle(c, w * .2f, ctr, style = stroke())
    for (i in 0 until 8) {
        val a = Math.toRadians(i * 45.0)
        val cs = Math.cos(a).toFloat(); val sn = Math.sin(a).toFloat()
        drawLine(c, ctr + Offset(cs, sn) * (w * .33f), ctr + Offset(cs, sn) * (w * .46f), w * .1f, StrokeCap.Round)
    }
}

fun DrawScope.appsIcon(c: Color) { // 2x2 tor
    val w = size.width; val s = w * .38f
    for (x in listOf(.08f, .54f)) for (y in listOf(.08f, .54f))
        drawRoundRect(c, Offset(x * w, y * w), Size(s, s), androidx.compose.ui.geometry.CornerRadius(w * .09f))
}

fun DrawScope.themeIcon(c: Color) { // yarı dolu dairə
    val w = size.width
    drawCircle(c, w * .42f, Offset(w / 2, w / 2), style = stroke())
    drawArc(c, 90f, 180f, true, Offset(w * .08f, w * .08f), Size(w * .84f, w * .84f))
}
